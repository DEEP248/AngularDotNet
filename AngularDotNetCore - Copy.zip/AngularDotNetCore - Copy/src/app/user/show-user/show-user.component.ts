import { Component, OnInit } from '@angular/core';
import { ApiserviceService } from 'src/app/apiservice.service';

@Component({
  selector: 'app-show-user',
  templateUrl: './show-user.component.html',
  styleUrls: ['./show-user.component.css']
})
export class ShowUserComponent implements OnInit {

  constructor(private service: ApiserviceService) { }

  UserList: any = [];
  ModalTitle = "";
  ActivateAddEditUsrComp: boolean = false;
  usr: any;

  ngOnInit(): void {
    this.refreshEmpList();
  }

  addClick() {
    this.usr = {
      UserId: "0",
      UserName: "",
      Department: "",
      DateOfJoining: "",
      PhotoFileName: "anonymous.png"
    }
    this.ModalTitle = "Add User";
    this.ActivateAddEditUsrComp = true;
  }

  editClick(item: any) {
    this.usr = item;
    this.ModalTitle = "Edit User";
    this.ActivateAddEditUsrComp = true;
  }

  deleteClick(item: any) {
    if (confirm('Are you sure??')) {
      this.service.deleteUser(item.UserId).subscribe(data => {
        alert(data.toString());
        this.refreshEmpList();
      })
    }
  }

  closeClick() {
    this.ActivateAddEditUsrComp = false;
    this.refreshEmpList();
  }

  refreshEmpList() {
    this.service.getUserList().subscribe(data => {
      this.UserList = data;
    });
  }
}