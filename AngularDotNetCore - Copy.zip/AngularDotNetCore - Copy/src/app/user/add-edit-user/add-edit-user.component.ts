import { Component, Input, OnInit } from '@angular/core';
import { ApiserviceService } from 'src/app/apiservice.service';

@Component({
  selector: 'app-add-edit-user',
  templateUrl: './add-edit-user.component.html',
  styleUrls: ['./add-edit-user.component.css']
})
export class AddEditUserComponent implements OnInit {

  constructor(private service: ApiserviceService) { }
  @Input() usr: any;
  UserId = "";
  UserName = "";
  Task = "";
  DateOfJoining = "";
  PhotoFileName = "";
  PhotoFilePath = "";
  TaskList: any = [];


  ngOnInit(): void {
    this.loadUserList();
  }

  loadUserList() {

    this.service.getAllTaskNames().subscribe((data: any) => {
      this.TaskList = data;

      this.UserId = this.usr.UserId;
      this.UserName = this.usr.UserName;
      this.Task = this.usr.Task;
      this.DateOfJoining = this.usr.DateOfJoining;
      this.PhotoFileName = this.usr.PhotoFileName;
      this.PhotoFilePath = this.service.photoUrl + this.PhotoFileName;
    });
  }

  addUser() {
    var val = {
      UserId: this.UserId,
      UserName: this.UserName,
      Task: this.Task,
      DateOfJoining: this.DateOfJoining,
      PhotoFileName: this.PhotoFileName
    };

    this.service.addUser(val).subscribe(res => {
      alert(res.toString());
    });
  }

  updateUser() {
    var val = {
      UserId: this.UserId,
      UserName: this.UserName,
      Task: this.Task,
      DateOfJoining: this.DateOfJoining,
      PhotoFileName: this.PhotoFileName
    };

    this.service.updateUser(val).subscribe(res => {
      alert(res.toString());
    });
  }


  uploadPhoto(event: any) {
    var file = event.target.files[0];
    const formData: FormData = new FormData();
    formData.append('file', file, file.name);

    this.service.uploadPhoto(formData).subscribe((data: any) => {
      this.PhotoFileName = data.toString();
      this.PhotoFilePath = this.service.photoUrl + this.PhotoFileName;
    })
  }
}