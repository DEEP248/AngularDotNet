import { Component, OnInit } from '@angular/core';
import { ApiserviceService } from 'src/app/apiservice.service';

@Component({
  selector: 'app-show-task',
  templateUrl: './show-task.component.html',
  styleUrls: ['./show-task.component.css']
})
export class ShowTaskComponent implements OnInit {

  constructor(private service: ApiserviceService) { }

  TaskList: any = [];
  ModalTitle = "";
  ActivateAddEditTaskComp: boolean = false;
  tasks: any;

  TaskIdFilter = "";
  TaskNameFilter = "";
  TaskListWithoutFilter: any = [];

  ngOnInit(): void {
    this.refreshDepList();
  }

  addClick() {
    this.tasks = {
      TaskId: "0",
      TaskName: ""
    }
    this.ModalTitle = "Add Task";
    this.ActivateAddEditTaskComp = true;
  }

  editClick(item: any) {
    this.tasks = item;
    this.ModalTitle = "Edit Task";
    this.ActivateAddEditTaskComp = true;
  }

  deleteClick(item: any) {
    if (confirm('Are you sure??')) {
      this.service.deleteTask(item.TaskId).subscribe(data => {
        alert(data.toString());
        this.refreshDepList();
      })
    }
  }

  closeClick() {
    this.ActivateAddEditTaskComp = false;
    this.refreshDepList();
  }


  refreshDepList() {
    this.service.getTaskList().subscribe(data => {
      this.TaskList = data;
      this.TaskListWithoutFilter = data;
    });
  }

  sortResult(prop: any, asc: any) {
    this.TaskList = this.TaskListWithoutFilter.sort(function (a: any, b: any) {
      if (asc) {
        return (a[prop] > b[prop]) ? 1 : ((a[prop] < b[prop]) ? -1 : 0);
      }
      else {
        return (b[prop] > a[prop]) ? 1 : ((b[prop] < a[prop]) ? -1 : 0);
      }
    });
  }

  FilterFn() {
    var TaskIdFilter = this.TaskIdFilter;
    var TaskNameFilter = this.TaskNameFilter;

    this.TaskList = this.TaskListWithoutFilter.filter(
      function (el: any) {
        return el.TaskId.toString().toLowerCase().includes(
          TaskIdFilter.toString().trim().toLowerCase()
        ) &&
          el.TaskName.toString().toLowerCase().includes(
            TaskNameFilter.toString().trim().toLowerCase())
      }
    );
  }
}