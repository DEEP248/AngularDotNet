import { Component, OnInit, Input } from '@angular/core';
import { ApiserviceService } from 'src/app/apiservice.service';

@Component({
  selector: 'app-add-edit-task',
  templateUrl: './add-edit-task.component.html',
  styleUrls: ['./add-edit-task.component.css']
})
export class AddEditTaskComponent implements OnInit {

  constructor(private service: ApiserviceService) { }

  @Input() tasks: any;
  TaskId = "";
  TaskName = "";

  ngOnInit(): void {

    this.TaskId = this.tasks.TaskId;
    this.TaskName = this.tasks.TaskName;
  }

  addTask() {
    var dept = {
      TaskId: this.TaskId,
      TaskName: this.TaskName
    };
    this.service.addTask(dept).subscribe(res => {
      alert(res.toString());
    });
  }

  updateTask() {
    var dept = {
      TaskId: this.TaskId,
      TaskName: this.TaskName
    };
    this.service.updateTask(dept).subscribe(res => {
      alert(res.toString());
    });
  }
}