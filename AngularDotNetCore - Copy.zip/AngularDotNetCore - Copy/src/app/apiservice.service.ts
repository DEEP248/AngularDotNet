import { Injectable } from '@angular/core';
import { HttpClient, HttpEvent, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ApiserviceService {
  readonly apiUrl = 'http://localhost:7095/api/';
  readonly photoUrl = "http://localhost:7095/Photos/";

  constructor(private http: HttpClient) { }

  // Task
  getTaskList(): Observable<any[]> {
    return this.http.get<any[]>(this.apiUrl + 'task/GetTask');
  }

  addTask(tsk: any): Observable<any> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    return this.http.post<any>(this.apiUrl + 'task/AddTask', tsk, httpOptions);
  }

  updateTask(tsk: any): Observable<any> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    return this.http.put<any>(this.apiUrl + 'task/UpdateTask/', tsk, httpOptions);
  }

  deleteTask(tskId: number): Observable<number> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    return this.http.delete<number>(this.apiUrl + 'task/DeleteTask/' + tskId, httpOptions);
  }

  // User
  getUserList(): Observable<any[]> {
    return this.http.get<any[]>(this.apiUrl + 'user/GetUser');
  }

  addUser(usr: any): Observable<any> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    return this.http.post<any>(this.apiUrl + 'user/AddUser', usr, httpOptions);
  }

  updateUser(usr: any): Observable<any> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    return this.http.put<any>(this.apiUrl + 'user/UpdateUser/', usr, httpOptions);
  }

  deleteUser(usrId: number): Observable<number> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    return this.http.delete<number>(this.apiUrl + 'user/DeleteUser/' + usrId, httpOptions);
  }

  uploadPhoto(photo: any) {
    return this.http.post(this.apiUrl + 'user/savefile', photo);
  }

  getAllTaskNames(): Observable<any[]> {
    return this.http.get<any[]>(this.apiUrl + 'user/GetAllTaskNames');
  }

} 