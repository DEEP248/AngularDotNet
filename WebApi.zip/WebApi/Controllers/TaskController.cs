﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;
using WebApi.Models;

namespace WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TaskController : Controller
    {
        private readonly ITaskRepository _task;
        public TaskController(ITaskRepository tskartment)
        {
            _task = tskartment ??
                throw new ArgumentNullException(nameof(tskartment));
        }
        [HttpGet]
        [Route("GetTask")]
        public async Task<IActionResult> Get()
        {
            return Ok(await _task.GetTask());
        }
        [HttpGet]
        [Route("GetTaskByID/{Id}")]
        public async Task<IActionResult> GetDeptById(int Id)
        {
            return Ok(await _task.GetTaskByID(Id));
        }
        [HttpPost]
        [Route("AddTask")]
        public async Task<IActionResult> Post(TaskModel tsk)
        {
            var result = await _task.InsertTask(tsk);
            if (result.TaskId == 0)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Something Went Wrong");
            }
            return Ok("Added Successfully");
        }
        [HttpPut]
        [Route("UpdateTask")]
        public async Task<IActionResult> Put(TaskModel tsk)
        {
            await _task.UpdateTask(tsk);
            return Ok("Updated Successfully");
        }
        [HttpDelete]
        //[HttpDelete("{id}")]
        [Route("DeleteTask")]
        public JsonResult Delete(int id)
        {
            _task.DeleteTask(id);
            return new JsonResult("Deleted Successfully");
        }
    }
}
