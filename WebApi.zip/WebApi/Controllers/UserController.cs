﻿using Microsoft.AspNetCore.Mvc;
using WebApi.Models;

namespace WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IUserRepository _user;
        private readonly ITaskRepository _task;
        private readonly IWebHostEnvironment _env;

        public UserController(IWebHostEnvironment env)
        {
            _env = env;
        }

        public UserController(IUserRepository user, ITaskRepository task)
        {
            _user = user ??
                throw new ArgumentNullException(nameof(user));
            _task = task ??
                throw new ArgumentNullException(nameof(task));
        }
        [HttpGet]
        [Route("GetUser")]
        public async Task<IActionResult> Get()
        {
            return Ok(await _user.GetUsers());
        }
        [HttpGet]
        [Route("GetUserByID/{Id}")]
        public async Task<IActionResult> GetEmpByID(int Id)
        {
            return Ok(await _user.GetUserByID(Id));
        }
        [HttpPost]
        [Route("AddUser")]
        public async Task<IActionResult> Post(UserModel usr)
        {
            var result = await _user.InsertUser(usr);
            if (result.UserID == 0)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Something Went Wrong");
            }
            return Ok("Added Successfully");
        }
        [HttpPut]
        [Route("UpdateUser")]
        public async Task<IActionResult> Put(UserModel usr)
        {
            await _user.UpdateUser(usr);
            return Ok("Updated Successfully");
        }
        [HttpDelete]
        [Route("DeleteUser")]
        //[HttpDelete("{id}")]
        public JsonResult Delete(int id)
        {
            var result = _user.DeleteUser(id);
            return new JsonResult("Deleted Successfully");
        }

        [Route("SaveFile")]
        [HttpPost]
        public JsonResult SaveFile()
        {
            try
            {
                var httpRequest = Request.Form;
                var postedFile = httpRequest.Files[0];
                string filename = postedFile.FileName;
                var physicalPath = _env.ContentRootPath + "/Photos/" + filename;

                using (var stream = new FileStream(physicalPath, FileMode.Create))
                {
                    stream.CopyTo(stream);
                }

                return new JsonResult(filename);
            }
            catch (Exception)
            {
                return new JsonResult("anonymous.png");
            }
        }

        [HttpGet]
        [Route("GetTask")]
        public async Task<IActionResult> GetAllTaskNames()
        {
            return Ok(await _task.GetTask());
        }
    }
}
