﻿using WebApi.Models;

public interface ITaskRepository
{
    Task<IEnumerable<TaskModel>> GetTask();
    Task<TaskModel> GetTaskByID(int ID);
    Task<TaskModel> InsertTask(TaskModel objTask);
    Task<TaskModel> UpdateTask(TaskModel objTask);
    bool DeleteTask(int ID);
}