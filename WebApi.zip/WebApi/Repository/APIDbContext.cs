﻿using Microsoft.EntityFrameworkCore;
using WebApi.Models;

namespace WebApi.Models
{

    public class APIDbContext : DbContext
    {
        public APIDbContext(DbContextOptions<APIDbContext> options) : base(options) { }
        public DbSet<TaskModel> TaskModels
        {
            get;
            set;
        }
        public DbSet<UserModel> UserModels
        {
            get;
            set;
        }
    }
}