﻿using Microsoft.EntityFrameworkCore;
using WebApi.Models;

public class TaskRepository : ITaskRepository
{
    private readonly APIDbContext _appDBContext;
    public TaskRepository(APIDbContext context)
    {
        _appDBContext = context ??
            throw new ArgumentNullException(nameof(context));
    }

    public async Task<IEnumerable<TaskModel>> GetTask()
    {
        return await _appDBContext.TaskModels.ToListAsync();
    }

    public async Task<TaskModel> GetTaskByID(int ID)
    {
        return await _appDBContext.TaskModels.FindAsync(ID);
    }

    public async Task<TaskModel> InsertTask(TaskModel objTask)
    {
        _appDBContext.TaskModels.Add(objTask);
        await _appDBContext.SaveChangesAsync();
        return objTask;
    }
    public async Task<TaskModel> UpdateTask(TaskModel objTask)
    {
        _appDBContext.Entry(objTask).State = EntityState.Modified;
        await _appDBContext.SaveChangesAsync();
        return objTask;
    }
    public bool DeleteTask(int ID)
    {
        bool result = false;
        var task = _appDBContext.TaskModels.Find(ID);
        if (task != null)
        {
            _appDBContext.Entry(task).State = EntityState.Deleted;
            _appDBContext.SaveChanges();
            result = true;
        }
        else
        {
            result = false;
        }
        return result;
    }

}