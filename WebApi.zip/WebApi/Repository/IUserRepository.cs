﻿using WebApi.Models;

public interface IUserRepository
{
    Task<IEnumerable<UserModel>> GetUsers();
    Task<UserModel> GetUserByID(int ID);
    Task<UserModel> InsertUser(UserModel objUser);
    Task<UserModel> UpdateUser(UserModel objUser);
    bool DeleteUser(int ID);
}