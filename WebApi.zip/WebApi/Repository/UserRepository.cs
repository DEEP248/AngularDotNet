﻿using Microsoft.EntityFrameworkCore;
using WebApi.Models;

public class UserRepository : IUserRepository
{
    private readonly APIDbContext _appDBContext;
    public UserRepository(APIDbContext context)
    {
        _appDBContext = context ??
            throw new ArgumentNullException(nameof(context));
    }
    public async Task<IEnumerable<UserModel>> GetUsers()
    {
        return await _appDBContext.UserModels.ToListAsync();
    }
    public async Task<UserModel> GetUserByID(int ID)
    {
        return await _appDBContext.UserModels.FindAsync(ID);
    }
    public async Task<UserModel> InsertUser(UserModel objUser)
    {
        _appDBContext.UserModels.Add(objUser);
        await _appDBContext.SaveChangesAsync();
        return objUser;
    }
    public async Task<UserModel> UpdateUser(UserModel objUser)
    {
        _appDBContext.Entry(objUser).State = EntityState.Modified;
        await _appDBContext.SaveChangesAsync();
        return objUser;
    }
    public bool DeleteUser(int ID)
    {
        bool result = false;
        var task = _appDBContext.UserModels.Find(ID);
        if (task != null)
        {
            _appDBContext.Entry(task).State = EntityState.Deleted;
            _appDBContext.SaveChanges();
            result = true;
        }
        else
        {
            result = false;
        }
        return result;
    }
}