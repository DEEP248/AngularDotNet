﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace WebApi.Models
{
    [Table("User")]
    public class UserModel
    {
        [Key]
        public int UserID { get; set; }
        public string UserName { get; set; }
        public string Task { get; set; }
        public string EmailId { get; set; }
        public DateTime DOJ { get; set; }
    }
   
}
