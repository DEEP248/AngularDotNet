﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace WebApi.Models
{
    [Table("tbTask")]
    public class TaskModel
    {

            [Key]
            public int TaskId { get; set; }

            public string TaskName { get; set; }
    }
}
